import React from 'react';

export default function App() {
  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#000',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '3rem',
      fontFamily: 'Arial, sans-serif'
    }}>
      <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>VaultX</h1>
      <p style={{ maxWidth: '600px', textAlign: 'center', marginBottom: '2rem' }}>
        Real-world asset-backed wealth, powered by blockchain. Stake, hold, and grow with VaultX —
        the decentralized vault for Bitcoin, real estate, and gold.
      </p>
      <div style={{ display: 'flex', gap: '1rem', marginBottom: '3rem' }}>
        <button style={{ padding: '0.75rem 1.5rem', fontSize: '1rem' }}>Connect Wallet</button>
        <a href="/VaultX_Whitepaper.pdf" download style={{ padding: '0.75rem 1.5rem', fontSize: '1rem', backgroundColor: '#fff', color: '#000', textDecoration: 'none' }}>Whitepaper</a>
      </div>
      <footer style={{ marginTop: 'auto', color: '#aaa', fontSize: '0.8rem' }}>
        VaultX © 2025. All rights reserved.
      </footer>
    </div>
  );
}
